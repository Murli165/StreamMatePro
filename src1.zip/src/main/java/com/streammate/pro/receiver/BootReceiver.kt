package com.streammate.pro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.streammate.pro.MainActivity
import com.streammate.pro.data.PlaylistRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (
            action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = context.getSharedPreferences(
                PlaylistRepository.PREFS_NAME,
                Context.MODE_PRIVATE
            )
            val startOnBoot = prefs.getBoolean(PlaylistRepository.KEY_START_ON_BOOT, false)
            if (startOnBoot) {
                val launchIntent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(launchIntent)
            }
        }
    }
}
