package com.streammate.pro.data

import com.streammate.pro.model.Channel
import org.json.JSONObject

object M3uParser {

    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")

    fun parse(content: String, sourceUrl: String = ""): List<Channel> {
        val lines = content.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        if (lines.isEmpty()) return emptyList()

        // Support direct HLS master/media playlists (.m3u8)
        val isDirectHls = lines.any {
            it.startsWith("#EXT-X-STREAM-INF") || it.startsWith("#EXT-X-TARGETDURATION")
        }
        if (isDirectHls && sourceUrl.isNotBlank()) {
            return listOf(
                Channel(
                    id = "direct_1",
                    number = 1,
                    name = "Direct HLS Stream",
                    streamUrl = sourceUrl,
                    category = "Live Streams"
                )
            )
        }

        val channels = mutableListOf<Channel>()
        var currentName: String? = null
        var currentCategory = "General"
        var currentLogo: String? = null
        var currentTvgId: String? = null
        var currentUserAgent: String? = null
        var currentLicenseType: String? = null
        var currentLicenseKey: String? = null
        var currentHeaders = mutableMapOf<String, String>()

        for (line in lines) {
            when {
                line.startsWith("#EXTM3U") -> continue

                line.startsWith("#EXTINF:") -> {
                    val attrs = mutableMapOf<String, String>()
                    attrRegex.findAll(line).forEach { match ->
                        attrs[match.groupValues[1].lowercase()] = match.groupValues[2]
                    }

                    val commaIndex = line.lastIndexOf(',')
                    val parsedName = if (commaIndex != -1 && commaIndex < line.length - 1) {
                        line.substring(commaIndex + 1).trim()
                    } else {
                        attrs["tvg-name"].orEmpty().ifBlank { "Channel ${channels.size + 1}" }
                    }

                    currentName = parsedName.ifBlank { "Channel ${channels.size + 1}" }
                    currentCategory = attrs["group-title"].orEmpty().ifBlank { "General" }
                    currentLogo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    currentTvgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() }
                }

                line.startsWith("#EXTGRP:") -> {
                    val grp = line.removePrefix("#EXTGRP:").trim()
                    if (grp.isNotBlank()) {
                        currentCategory = grp
                    }
                }

                line.startsWith("#EXTVLCOPT:http-user-agent=") -> {
                    currentUserAgent = line.removePrefix("#EXTVLCOPT:http-user-agent=").trim()
                }

                line.startsWith("#KODIPROP:inputstream.adaptive.license_type=") -> {
                    currentLicenseType = line.removePrefix("#KODIPROP:inputstream.adaptive.license_type=").trim()
                }

                line.startsWith("#KODIPROP:inputstream.adaptive.license_key=") -> {
                    currentLicenseKey = line.removePrefix("#KODIPROP:inputstream.adaptive.license_key=").trim()
                }

                line.startsWith("#EXTHTTP:") -> {
                    val jsonPart = line.removePrefix("#EXTHTTP:").trim()
                    runCatching {
                        val obj = JSONObject(jsonPart)
                        obj.keys().forEach { key ->
                            currentHeaders[key] = obj.optString(key)
                        }
                    }
                }

                !line.startsWith("#") -> {
                    val streamUrl = resolveUrl(line, sourceUrl)
                    val channelNumber = channels.size + 1
                    channels.add(
                        Channel(
                            id = "${channelNumber}_${streamUrl.hashCode()}",
                            number = channelNumber,
                            name = currentName ?: "Channel $channelNumber",
                            streamUrl = streamUrl,
                            category = currentCategory,
                            logoUrl = currentLogo,
                            tvgId = currentTvgId,
                            customUserAgent = currentUserAgent,
                            drmLicenseType = currentLicenseType,
                            drmLicenseUrl = currentLicenseKey,
                            httpHeaders = currentHeaders.toMap()
                        )
                    )
                    currentName = null
                    currentCategory = "General"
                    currentLogo = null
                    currentTvgId = null
                    currentUserAgent = null
                    currentLicenseType = null
                    currentLicenseKey = null
                    currentHeaders = mutableMapOf()
                }
            }
        }

        return channels
    }

    private fun resolveUrl(entryUrl: String, baseUrl: String): String {
        if (entryUrl.startsWith("http://") || entryUrl.startsWith("https://")) {
            return entryUrl
        }
        if (baseUrl.isBlank()) return entryUrl
        return try {
            java.net.URI(baseUrl).resolve(entryUrl).toString()
        } catch (_: Exception) {
            entryUrl
        }
    }
}
