package com.streammate.pro.data

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSourceInputStream
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import com.streammate.pro.model.AppThemeId
import com.streammate.pro.model.Channel
import com.streammate.pro.model.PlaylistSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class PlaylistRepository(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSavedPlaylists(): List<PlaylistSource> {
        val rawJson = prefs.getString(KEY_PLAYLISTS, null)
        if (rawJson.isNullOrBlank()) {
            val defaultPlaylist = createPreloadedPlaylist()
            savePlaylists(listOf(defaultPlaylist))
            return listOf(defaultPlaylist)
        }

        return try {
            val array = JSONArray(rawJson)
            val list = mutableListOf<PlaylistSource>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    PlaylistSource(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        url = obj.getString("url"),
                        userAgent = obj.optString("userAgent", getDefaultUserAgent())
                    )
                )
            }
            list.ifEmpty { listOf(createPreloadedPlaylist()) }
        } catch (_: Exception) {
            listOf(createPreloadedPlaylist())
        }
    }

    private fun createPreloadedPlaylist(): PlaylistSource = PlaylistSource(
        id = DEFAULT_PLAYLIST_ID,
        name = PlaylistSource.PRELOADED_NAME,
        url = PlaylistSource.PRELOADED_URL,
        userAgent = getDefaultUserAgent()
    )

    fun savePlaylists(playlists: List<PlaylistSource>) {
        val array = JSONArray()
        playlists.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("url", item.url)
                    put("userAgent", item.userAgent)
                }
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, array.toString()).apply()
    }

    fun getActivePlaylistId(): String =
        prefs.getString(KEY_ACTIVE_ID, DEFAULT_PLAYLIST_ID) ?: DEFAULT_PLAYLIST_ID

    fun setActivePlaylistId(id: String) {
        prefs.edit().putString(KEY_ACTIVE_ID, id).apply()
    }

    fun getFavoriteUrls(): Set<String> =
        prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()

    fun saveFavoriteUrls(urls: Set<String>) {
        prefs.edit().putStringSet(KEY_FAVORITES, urls).apply()
    }

    fun getThemeId(): AppThemeId {
        val raw = prefs.getString(KEY_THEME_ID, AppThemeId.CYBER_NEON.name)
        return runCatching { AppThemeId.valueOf(raw ?: AppThemeId.CYBER_NEON.name) }
            .getOrDefault(AppThemeId.CYBER_NEON)
    }

    fun setThemeId(themeId: AppThemeId) {
        prefs.edit().putString(KEY_THEME_ID, themeId.name).apply()
    }

    fun getStartOnBoot(): Boolean = prefs.getBoolean(KEY_START_ON_BOOT, false)

    fun setStartOnBoot(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_START_ON_BOOT, enabled).apply()
    }

    fun getAutoPlayLastChannel(): Boolean = prefs.getBoolean(KEY_AUTO_PLAY_LAST, true)

    fun setAutoPlayLastChannel(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_PLAY_LAST, enabled).apply()
    }

    fun getLastChannelUrl(): String? = prefs.getString(KEY_LAST_CHANNEL_URL, null)

    fun setLastChannelUrl(url: String) {
        prefs.edit().putString(KEY_LAST_CHANNEL_URL, url).apply()
    }

    fun getDefaultUserAgent(): String =
        prefs.getString(KEY_DEFAULT_UA, PlaylistSource.DEFAULT_USER_AGENT)
            ?: PlaylistSource.DEFAULT_USER_AGENT

    fun setDefaultUserAgent(userAgent: String) {
        prefs.edit().putString(KEY_DEFAULT_UA, userAgent.ifBlank { PlaylistSource.DEFAULT_USER_AGENT }).apply()
    }

    @OptIn(UnstableApi::class)
    suspend fun fetchChannels(source: PlaylistSource): Result<List<Channel>> = withContext(Dispatchers.IO) {
        runCatching {
            val userAgent = source.userAgent.ifBlank { getDefaultUserAgent() }
            val cookie = runCatching { CookieManager.getInstance().getCookie(source.url) }.getOrNull()

            val headers = buildMap {
                put("Accept", "*/*")
                if (!cookie.isNullOrBlank()) {
                    put("Cookie", cookie)
                }
            }

            // Use Media3 DefaultHttpDataSource.Factory so playlist downloads share the exact User-Agent & headers
            val dataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(20_000)
                .setDefaultRequestProperties(headers)

            val dataSource = dataSourceFactory.createDataSource()
            val dataSpec = DataSpec(Uri.parse(source.url))

            val content = try {
                DataSourceInputStream(dataSource, dataSpec).use { stream ->
                    stream.bufferedReader().readText()
                }
            } finally {
                runCatching { dataSource.close() }
            }

            if (content.isBlank()) {
                error("Playlist response was empty")
            }

            M3uParser.parse(content, source.url)
        }
    }

    companion object {
        const val PREFS_NAME = "streammate_pro_prefs"
        const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_PLAYLISTS = "saved_playlists_v1"
        private const val KEY_ACTIVE_ID = "active_playlist_id_v1"
        private const val KEY_FAVORITES = "favorite_channels_v1"
        private const val KEY_THEME_ID = "app_theme_v1"
        private const val KEY_AUTO_PLAY_LAST = "auto_play_last_v1"
        private const val KEY_LAST_CHANNEL_URL = "last_channel_url_v1"
        private const val KEY_DEFAULT_UA = "default_user_agent_v1"
        const val DEFAULT_PLAYLIST_ID = "preloaded_jtv39"
    }
}
