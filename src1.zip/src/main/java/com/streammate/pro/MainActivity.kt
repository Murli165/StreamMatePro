package com.streammate.pro

import android.app.PictureInPictureParams
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var isPlayerActive = false
    private val inPipState = mutableStateOf(false)

    private fun enterPipIfPossible() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isPlayerActive) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Exception) { }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        enterPipIfPossible()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPipState.value = isInPictureInPictureMode
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = BgBlack,
                    surface = CardDark,
                    primary = AccentCyan,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                StreamMateProApp(
                    isInPipMode = inPipState.value,
                    onPlayerActiveChanged = { isPlayerActive = it },
                    onRequestPip = { enterPipIfPossible() }
                )
            }
        }
    }
}

@Composable
fun StreamMateProApp(
    isInPipMode: Boolean,
    onPlayerActiveChanged: (Boolean) -> Unit,
    onRequestPip: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("streammate_nuvio", Context.MODE_PRIVATE) }

    var currentTab by remember { mutableIntStateOf(0) }
    var sources by remember { mutableStateOf(loadSources(prefs)) }
    var settings by remember { mutableStateOf(loadSettings(prefs)) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var favoriteIds by remember { mutableStateOf(prefs.getStringSet("favs", emptySet()) ?: emptySet()) }
    var recentIds by remember { mutableStateOf(loadRecentIds(prefs)) }
    var playingChannel by remember { mutableStateOf<Channel?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }

    LaunchedEffect(playingChannel) {
        onPlayerActiveChanged(playingChannel != null)
    }

    fun refreshAllChannels(sourceList: List<PlaylistSource>, activeSettings: AppSettings = settings) {
        if (sourceList.isEmpty()) {
            channels = emptyList()
            return
        }
        scope.launch {
            isLoading = true
            statusMsg = "Loading (${activeSettings.uaPreset} UA)..."
            val ua = resolveUserAgent(activeSettings)
            val allLoaded = mutableListOf<Channel>()
            for (src in sourceList) {
                if (src.type == "M3U" || src.type == "XTREAM" || src.type == "STALKER") {
                    allLoaded.addAll(fetchAndParseM3U(src.url, ua))
                }
            }
            channels = allLoaded.distinctBy { it.url }
            statusMsg = if (channels.isEmpty()) "No channels found. Check URL/UA." else "${channels.size} channels loaded"
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        if (sources.isNotEmpty()) refreshAllChannels(sources)
    }

    fun toggleFavorite(channel: Channel) {
        val updated = favoriteIds.toMutableSet()
        if (updated.contains(channel.id)) updated.remove(channel.id) else updated.add(channel.id)
        favoriteIds = updated
        prefs.edit().putStringSet("favs", updated).apply()
    }

    fun playChannel(channel: Channel) {
        playingChannel = channel
        val updatedRecent = (listOf(channel.id) + recentIds.filter { it != channel.id }).take(15)
        recentIds = updatedRecent
        prefs.edit().putString("recents", updatedRecent.joinToString(",")).apply()
    }

    if (playingChannel != null) {
        BackHandler { playingChannel = null }
        ProPlayerScreen(
            channel = playingChannel!!,
            allChannels = channels,
            isFavorite = favoriteIds.contains(playingChannel!!.id),
            settings = settings,
            isInPipMode = isInPipMode,
            onSelectChannel = ::playChannel,
            onToggleFavorite = { toggleFavorite(playingChannel!!) },
            onEnterPip = onRequestPip,
            onBack = { playingChannel = null }
        )
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(BgBlack).statusBarsPadding()) {
        Column(modifier = Modifier.fillMaxSize().padding(bottom = 84.dp)) {
            when (currentTab) {
                0 -> HomeScreen(channels, recentIds, favoriteIds, isLoading, ::playChannel, { currentTab = 4 }, { currentTab = 1 })
                1 -> LiveTvScreen(channels, favoriteIds, isLoading, ::playChannel, ::toggleFavorite) { refreshAllChannels(sources) }
                2 -> SearchScreen(channels, ::playChannel)
                3 -> LibraryScreen(channels, favoriteIds, ::playChannel, ::toggleFavorite)
                4 -> SourcesAndSettingsScreen(
                    sources = sources,
                    settings = settings,
                    statusMsg = statusMsg,
                    onUpdateSettings = { newS ->
                        settings = newS
                        saveSettings(prefs, newS)
                    },
                    onAddSource = { newSrc ->
                        val updated = sources + newSrc
                        sources = updated
                        saveSources(prefs, updated)
                        refreshAllChannels(updated)
                    },
                    onDeleteSource = { delSrc ->
                        val updated = sources.filter { it.id != delSrc.id }
                        sources = updated
                        saveSources(prefs, updated)
                        refreshAllChannels(updated)
                    }
                )
            }
        }

        // Floating Nuvio Pill Bottom Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .navigationBarsPadding()
                .height(62.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(32.dp),
            color = Color(0xEE16161D),
            border = BorderStroke(1.dp, BorderSubtle),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavPillItem(Icons.Default.Home, "Home", currentTab == 0) { currentTab = 0 }
                NavPillItem(Icons.Default.LiveTv, "Live TV", currentTab == 1) { currentTab = 1 }
                NavPillItem(Icons.Default.Search, "Search", currentTab == 2) { currentTab = 2 }
                NavPillItem(Icons.Default.Bookmarks, "Library", currentTab == 3) { currentTab = 3 }
                NavPillItem(Icons.Default.Settings, "Sources", currentTab == 4) { currentTab = 4 }
            }
        }
    }
}

@Composable
fun NavPillItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .background(if (selected) AccentCyan.copy(alpha = 0.2f) else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Icon(icon, label, tint = if (selected) AccentCyan else TextSecondary, modifier = Modifier.size(22.dp))
        Text(label, fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) Color.White else TextSecondary)
    }
}
@Composable
fun HomeScreen(
    channels: List<Channel>,
    recentIds: List<String>,
    favoriteIds: Set<String>,
    isLoading: Boolean,
    onPlay: (Channel) -> Unit,
    onGoToSources: () -> Unit,
    onGoToLive: () -> Unit
) {
    val recentChannels = recentIds.mapNotNull { id -> channels.find { it.id == id } }
    val favChannels = channels.filter { favoriteIds.contains(it.id) }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("StreamMate Pro", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (isLoading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = AccentCyan)
            }
        }
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF0A2E45), Color(0xFF101018))))
                    .clickable { if (channels.isNotEmpty()) onPlay(channels.first()) else onGoToSources() }
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.BottomStart), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (channels.isEmpty()) "WELCOME TO STREAMMATE" else "PRO PLAYER READY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AccentCyan, letterSpacing = 1.2.sp)
                    Text(if (channels.isEmpty()) "Add M3U, Xtream or Stalker" else "${channels.size} Channels Loaded", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Button(
                        onClick = { if (channels.isEmpty()) onGoToSources() else onGoToLive() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (channels.isEmpty()) "Add Source" else "Browse Live TV", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (recentChannels.isNotEmpty()) {
            item {
                Text("Continue Watching", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recentChannels) { ch -> ChannelPosterCard(ch) { onPlay(ch) } }
                }
            }
        }
        if (favChannels.isNotEmpty()) {
            item {
                Text("Your Favorites", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(favChannels) { ch -> ChannelPosterCard(ch) { onPlay(ch) } }
                }
            }
        }
    }
}

@Composable
fun ChannelPosterCard(channel: Channel, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.width(145.dp).height(105.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = CardDark,
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
            if (channel.logo.isNotBlank()) {
                AsyncImage(model = channel.logo, contentDescription = channel.name, modifier = Modifier.height(48.dp).fillMaxWidth(), contentScale = ContentScale.Fit)
            } else {
                Icon(Icons.Default.Tv, null, tint = AccentCyan, modifier = Modifier.size(40.dp))
            }
            Text(channel.name, color = TextPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun LiveTvScreen(
    channels: List<Channel>,
    favoriteIds: Set<String>,
    isLoading: Boolean,
    onPlay: (Channel) -> Unit,
    onToggleFav: (Channel) -> Unit,
    onRefresh: () -> Unit
) {
    val groups = remember(channels) { listOf("All") + channels.map { it.group }.distinct().sorted() }
    var selectedGroup by remember { mutableStateOf("All") }
    val filtered = remember(channels, selectedGroup) { if (selectedGroup == "All") channels else channels.filter { it.group == selectedGroup } }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Live TV", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            items(groups) { grp ->
                val active = grp == selectedGroup
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (active) Color.White else CardElevated,
                    border = BorderStroke(1.dp, if (active) Color.White else BorderSubtle),
                    modifier = Modifier.clickable { selectedGroup = grp }
                ) {
                    Text(grp, color = if (active) Color.Black else TextSecondary, fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
        }
        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AccentCyan) }
        } else if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No channels yet. Add a playlist in Sources.", color = TextSecondary) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered) { ch -> ChannelRowItem(ch, favoriteIds.contains(ch.id), { onPlay(ch) }, { onToggleFav(ch) }) }
            }
        }
    }
}

@Composable
fun ChannelRowItem(channel: Channel, isFavorite: Boolean, onClick: () -> Unit, onToggleFav: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), color = CardDark, border = BorderStroke(1.dp, BorderSubtle)) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(CardElevated), contentAlignment = Alignment.Center) {
                if (channel.logo.isNotBlank()) AsyncImage(model = channel.logo, contentDescription = null, modifier = Modifier.size(38.dp), contentScale = ContentScale.Fit)
                else Icon(Icons.Default.LiveTv, null, tint = AccentCyan)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(channel.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(channel.group, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onClick = onToggleFav) {
                Icon(if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder, "Fav", tint = if (isFavorite) Color(0xFFFFD54F) else TextSecondary)
            }
        }
    }
}

@Composable
fun SearchScreen(channels: List<Channel>, onPlay: (Channel) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, channels) { if (query.isBlank()) emptyList() else channels.filter { it.name.contains(query, true) || it.group.contains(query, true) } }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Search", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Search channels...", color = TextSecondary) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = TextSecondary) }, singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(results) { ch -> ChannelRowItem(ch, false, { onPlay(ch) }, {}) }
        }
    }
}

@Composable
fun LibraryScreen(channels: List<Channel>, favoriteIds: Set<String>, onPlay: (Channel) -> Unit, onToggleFav: (Channel) -> Unit) {
    val favs = channels.filter { favoriteIds.contains(it.id) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Library & Favorites", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(14.dp))
        if (favs.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Star your favorite channels to see them here.", color = TextSecondary) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(favs) { ch -> ChannelRowItem(ch, true, { onPlay(ch) }, { onToggleFav(ch) }) }
        }
    }
}

@Composable
fun SourcesAndSettingsScreen(
    sources: List<PlaylistSource>,
    settings: AppSettings,
    statusMsg: String,
    onUpdateSettings: (AppSettings) -> Unit,
    onAddSource: (PlaylistSource) -> Unit,
    onDeleteSource: (PlaylistSource) -> Unit
) {
    var dialogType by remember { mutableStateOf<String?>(null) }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Sources & Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            if (statusMsg.isNotBlank()) Text(statusMsg, color = AccentCyan, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                SourceAddChip("+ M3U", Modifier.weight(1f)) { dialogType = "M3U" }
                SourceAddChip("+ Xtream", Modifier.weight(1f)) { dialogType = "XTREAM" }
                SourceAddChip("+ Stalker", Modifier.weight(1f)) { dialogType = "STALKER" }
            }
        }
        // User-Agent Switcher
        item {
            Text("Global User-Agent", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("TiviMate", "OTT Navigator", "Custom").forEach { preset ->
                    val active = settings.uaPreset == preset
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (active) AccentCyan else CardElevated,
                        modifier = Modifier.clickable { onUpdateSettings(settings.copy(uaPreset = preset)) }
                    ) {
                        Text(preset, color = if (active) Color.Black else TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
            }
            if (settings.uaPreset == "Custom") {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = settings.customUa,
                    onValueChange = { onUpdateSettings(settings.copy(customUa = it)) },
                    label = { Text("Custom User-Agent") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        // Buffer Setting
        item {
            Text("Player Buffer Preset", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Low RAM (TV)", "Balanced", "High").forEach { mode ->
                    val active = settings.bufferMode == mode
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (active) AccentCyan else CardElevated,
                        modifier = Modifier.clickable { onUpdateSettings(settings.copy(bufferMode = mode)) }
                    ) {
                        Text(mode, color = if (active) Color.Black else TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
            }
        }
        item { Text("Active Playlists (${sources.size})", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        items(sources) { src ->
            Surface(shape = RoundedCornerShape(14.dp), color = CardDark, border = BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(src.name, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("${src.type} • ${src.url}", color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { onDeleteSource(src) }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF5252)) }
                }
            }
        }
    }

    if (dialogType != null) {
        AddSourceDialog(dialogType!!, { dialogType = null }) { src ->
            onAddSource(src)
            dialogType = null
        }
    }
}

@Composable
fun SourceAddChip(label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.height(44.dp).clickable(onClick = onClick), shape = RoundedCornerShape(12.dp), color = CardElevated, border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.6f))) {
        Box(contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
    }
}

@Composable
fun AddSourceDialog(type: String, onDismiss: () -> Unit, onSave: (PlaylistSource) -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("00:1A:79:") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardElevated,
        title = { Text("Add $type Source", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Playlist Name") }, singleLine = true)
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text(if (type == "M3U") "M3U URL" else "Server / Portal URL") }, singleLine = true)
                if (type == "XTREAM") {
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username") }, singleLine = true)
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true)
                }
                if (type == "STALKER") {
                    OutlinedTextField(value = mac, onValueChange = { mac = it }, label = { Text("MAC Address") }, singleLine = true)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanUrl = url.trim().removeSuffix("/")
                    val finalUrl = if (type == "XTREAM") "$cleanUrl/get.php?username=${username.trim()}&password=${password.trim()}&type=m3u_plus&output=ts" else cleanUrl
                    if (finalUrl.isNotBlank()) {
                        onSave(PlaylistSource(System.currentTimeMillis().toString(), name.ifBlank { "$type Playlist" }, type, finalUrl, if (type == "STALKER") mac else ""))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) { Text("Save", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) } }
    )
}

