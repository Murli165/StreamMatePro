package com.streammate.pro.player

import android.content.Context
import android.webkit.CookieManager
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.streammate.pro.model.PlaylistSource

class ExoPlayerManager(context: Context) {

    @OptIn(UnstableApi::class)
    private val dataSourceFactory: DefaultHttpDataSource.Factory = DefaultHttpDataSource.Factory()
        .setUserAgent(PlaylistSource.DEFAULT_USER_AGENT)
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15_000)
        .setReadTimeoutMs(20_000)

    @OptIn(UnstableApi::class)
    val player: ExoPlayer = ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
        .build()

    @OptIn(UnstableApi::class)
    fun playStream(
        streamUrl: String,
        userAgent: String,
        httpHeaders: Map<String, String> = emptyMap(),
        drmLicenseType: String? = null,
        drmLicenseUrl: String? = null
    ) {
        val resolvedUa = userAgent.ifBlank { PlaylistSource.DEFAULT_USER_AGENT }
        dataSourceFactory.setUserAgent(resolvedUa)

        val mergedHeaders = httpHeaders.toMutableMap()
        val webViewCookie = runCatching { CookieManager.getInstance().getCookie(streamUrl) }.getOrNull()
        if (!webViewCookie.isNullOrBlank() && !mergedHeaders.containsKey("Cookie") && !mergedHeaders.containsKey("cookie")) {
            mergedHeaders["Cookie"] = webViewCookie
        }
        dataSourceFactory.setDefaultRequestProperties(mergedHeaders)

        val itemBuilder = MediaItem.Builder().setUri(streamUrl)

        if (!drmLicenseUrl.isNullOrBlank()) {
            val drmUuid = when (drmLicenseType?.lowercase()) {
                "widevine", "com.widevine.alpha" -> C.WIDEVINE_UUID
                else -> C.CLEARKEY_UUID
            }
            itemBuilder.setDrmConfiguration(
                MediaItem.DrmConfiguration.Builder(drmUuid)
                    .setLicenseUri(drmLicenseUrl)
                    .build()
            )
        }

        player.setMediaItem(itemBuilder.build())
        player.prepare()
        player.playWhenReady = true
    }

    fun release() {
        player.release()
    }
}
