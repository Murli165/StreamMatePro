package com.streammate.pro

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// --- Nuvio Pitch-Black + Cyan Theme ---
val BgBlack = Color(0xFF070709)
val CardDark = Color(0xFF131318)
val CardElevated = Color(0xFF1C1C24)
val BorderSubtle = Color(0xFF282834)
val AccentCyan = Color(0xFF00D4FF)
val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFF9A9AA6)

data class Channel(
    val id: String,
    val name: String,
    val url: String,
    val logo: String = "",
    val group: String = "Live TV"
)

data class PlaylistSource(
    val id: String,
    val name: String,
    val type: String, // "M3U", "XTREAM", "STALKER"
    val url: String,
    val extra: String = ""
)

data class AppSettings(
    val uaPreset: String = "TiviMate", // "TiviMate", "OTT Navigator", "Custom"
    val customUa: String = "TiviMate/4.7.0 (Android)",
    val bufferMode: String = "Low RAM (TV)" // "Low RAM (TV)", "Balanced", "High"
)

fun resolveUserAgent(settings: AppSettings): String = when (settings.uaPreset) {
    "OTT Navigator" -> "OTT Navigator/1.7.1 (Linux; Android)"
    "Custom" -> settings.customUa.ifBlank { "TiviMate/4.7.0 (Android)" }
    else -> "TiviMate/4.7.0 (Android)"
}

suspend fun fetchAndParseM3U(urlStr: String, userAgent: String): List<Channel> = withContext(Dispatchers.IO) {
    val list = mutableListOf<Channel>()
    try {
        var currentUrl = urlStr.trim()
        var conn: HttpURLConnection
        var redirects = 0
        while (true) {
            conn = URL(currentUrl).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", "*/*")
            val code = conn.responseCode
            if (code in 300..399 && redirects < 5) {
                val loc = conn.getHeaderField("Location") ?: break
                currentUrl = URL(URL(currentUrl), loc).toString()
                redirects++
                conn.disconnect()
            } else break
        }
        val lines = conn.inputStream.bufferedReader().readLines()
        var currentName = ""
        var currentLogo = ""
        var currentGroup = "Live TV"
        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF:")) {
                currentName = line.substringAfterLast(",", "Channel").trim()
                currentLogo = Regex("""tvg-logo="([^"]*)"""").find(line)?.groupValues?.get(1) ?: ""
                currentGroup = Regex("""group-title="([^"]*)"""").find(line)?.groupValues?.get(1)?.ifBlank { "Live TV" } ?: "Live TV"
            } else if (line.isNotEmpty() && !line.startsWith("#") &&
                (line.startsWith("http") || line.startsWith("rtmp") || line.startsWith("rtsp"))
            ) {
                list.add(
                    Channel(
                        id = line.hashCode().toString(),
                        name = currentName.ifBlank { "Channel ${list.size + 1}" },
                        url = line,
                        logo = currentLogo,
                        group = currentGroup
                    )
                )
                currentName = ""
            }
        }
    } catch (_: Exception) { }
    list
}

class DvrRecorder {
    private var job: Job? = null

    fun start(
        context: Context,
        scope: CoroutineScope,
        streamUrl: String,
        channelName: String,
        userAgent: String,
        onStatus: (String) -> Unit
    ) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            var out: OutputStream? = null
            var conn: HttpURLConnection? = null
            try {
                val safeName = channelName.replace(Regex("[^A-Za-z0-9_-]"), "_").take(25)
                val fileName = "SM_${safeName}_${System.currentTimeMillis()}.ts"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp2t")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/StreamMatePro")
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) out = context.contentResolver.openOutputStream(uri)
                } else {
                    val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "StreamMatePro")
                    dir.mkdirs()
                    out = FileOutputStream(File(dir, fileName))
                }

                if (out == null) {
                    withContext(Dispatchers.Main) { onStatus("Storage error") }
                    return@launch
                }

                var currentUrl = streamUrl
                var redirects = 0
                while (true) {
                    conn = URL(currentUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000
                    conn.readTimeout = 20000
                    conn.setRequestProperty("User-Agent", userAgent)
                    val code = conn.responseCode
                    if (code in 300..399 && redirects < 5) {
                        val loc = conn.getHeaderField("Location") ?: break
                        currentUrl = URL(URL(currentUrl), loc).toString()
                        redirects++
                        conn.disconnect()
                    } else break
                }

                val input = conn!!.inputStream
                val buf = ByteArray(16 * 1024)
                withContext(Dispatchers.Main) { onStatus("Recording: $fileName") }
                while (isActive) {
                    val read = input.read(buf)
                    if (read == -1) break
                    out.write(buf, 0, read)
                }
                withContext(Dispatchers.Main) { onStatus("Saved: Movies/StreamMatePro/$fileName") }
            } catch (e: Exception) {
                if (isActive) {
                    withContext(Dispatchers.Main) { onStatus("DVR stopped") }
                }
            } finally {
                try { out?.flush(); out?.close() } catch (_: Exception) {}
                try { conn?.disconnect() } catch (_: Exception) {}
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }
}

fun saveSources(prefs: SharedPreferences, list: List<PlaylistSource>) {
    val arr = JSONArray()
    list.forEach {
        arr.put(JSONObject().apply {
            put("id", it.id); put("name", it.name); put("type", it.type)
            put("url", it.url); put("extra", it.extra)
        })
    }
    prefs.edit().putString("sources_json", arr.toString()).apply()
}

fun loadSources(prefs: SharedPreferences): List<PlaylistSource> {
    val raw = prefs.getString("sources_json", null) ?: return emptyList()
    val res = mutableListOf<PlaylistSource>()
    try {
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            res.add(PlaylistSource(o.getString("id"), o.getString("name"), o.getString("type"), o.getString("url"), o.optString("extra")))
        }
    } catch (_: Exception) { }
    return res
}

fun saveSettings(prefs: SharedPreferences, s: AppSettings) {
    prefs.edit()
        .putString("ua_preset", s.uaPreset)
        .putString("custom_ua", s.customUa)
        .putString("buffer_mode", s.bufferMode)
        .apply()
}

fun loadSettings(prefs: SharedPreferences): AppSettings = AppSettings(
    uaPreset = prefs.getString("ua_preset", "TiviMate") ?: "TiviMate",
    customUa = prefs.getString("custom_ua", "TiviMate/4.7.0 (Android)") ?: "TiviMate/4.7.0 (Android)",
    bufferMode = prefs.getString("buffer_mode", "Low RAM (TV)") ?: "Low RAM (TV)"
)

fun loadRecentIds(prefs: SharedPreferences): List<String> {
    val raw = prefs.getString("recents", "") ?: ""
    return if (raw.isBlank()) emptyList() else raw.split(",")
}
