package com.streammate.pro.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.streammate.pro.model.AppThemeId
import com.streammate.pro.model.PlaylistSource
import com.streammate.pro.ui.theme.LocalStreamMatePalette
import com.streammate.pro.ui.theme.paletteForTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsDialog(
    playlists: List<PlaylistSource>,
    activePlaylistId: String,
    themeId: AppThemeId,
    startOnBoot: Boolean,
    autoPlayLastChannel: Boolean,
    defaultUserAgent: String,
    onDismiss: () -> Unit,
    onSelectTheme: (AppThemeId) -> Unit,
    onToggleStartOnBoot: (Boolean) -> Unit,
    onToggleAutoPlayLast: (Boolean) -> Unit,
    onUpdateDefaultUserAgent: (String) -> Unit,
    onAddPlaylist: (name: String, url: String, userAgent: String) -> Unit,
    onSelectPlaylist: (String) -> Unit,
    onUpdatePlaylistUserAgent: (playlistId: String, newUserAgent: String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onVerifyCaptcha: (url: String) -> Unit,
    onReloadActive: () -> Unit
) {
    val palette = LocalStreamMatePalette.current
    val activePlaylist = playlists.find { it.id == activePlaylistId }

    var newName by remember { mutableStateOf("") }
    var newUrl by remember { mutableStateOf("") }
    var newUserAgent by remember { mutableStateOf(defaultUserAgent) }
    var activeUaDraft by remember(activePlaylistId) {
        mutableStateOf(activePlaylist?.userAgent ?: defaultUserAgent)
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = palette.primary,
        unfocusedBorderColor = palette.border,
        focusedTextColor = palette.textPrimary,
        unfocusedTextColor = palette.textPrimary,
        focusedLabelColor = palette.primary,
        unfocusedLabelColor = palette.textSecondary,
        cursorColor = palette.primary
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = palette.surface,
            border = BorderStroke(1.dp, palette.border),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 760.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Glowing Gradient Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.headerBrush)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "StreamMate Pro Settings",
                            color = palette.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Playback, TV Boot, Themes, Captcha & Unlimited M3U",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Settings",
                            tint = palette.textSecondary
                        )
                    }
                }

                HorizontalDivider(color = palette.border)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Playback & Boot Toggles
                    Text(
                        text = "Playback & Android TV Behaviour",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Start App on Boot",
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Auto-launch StreamMate Pro when phone or TV boots up",
                                color = palette.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = startOnBoot,
                            onCheckedChange = onToggleStartOnBoot,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = palette.primary
                            )
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Play Last Channel",
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Resume the last watched stream automatically at startup",
                                color = palette.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = autoPlayLastChannel,
                            onCheckedChange = onToggleAutoPlayLast,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = palette.primary
                            )
                        )
                    }

                    HorizontalDivider(color = palette.border)

                    // 2. Colour Theme Selector
                    Text(
                        text = "Colour Theme",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppThemeId.entries.forEach { option ->
                            val optionPalette = paletteForTheme(option)
                            val selected = option == themeId
                            OutlinedButton(
                                onClick = { onSelectTheme(option) },
                                border = BorderStroke(
                                    width = if (selected) 1.5.dp else 1.dp,
                                    color = if (selected) optionPalette.primary else palette.border
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) optionPalette.surfaceElevated else palette.canvas,
                                    contentColor = if (selected) optionPalette.primary else palette.textPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = option.displayName,
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = palette.border)

                    // 3. Default User-Agent Presets & Active Playlist User-Agent
                    Text(
                        text = "User-Agent Presets & Active Header",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PlaylistSource.USER_AGENT_PRESETS.forEach { preset ->
                            val isSelected = activeUaDraft == preset
                            OutlinedButton(
                                onClick = {
                                    activeUaDraft = preset
                                    newUserAgent = preset
                                    onUpdateDefaultUserAgent(preset)
                                    if (activePlaylist != null) {
                                        onUpdatePlaylistUserAgent(activePlaylist.id, preset)
                                    }
                                },
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) palette.primary else palette.border
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) palette.surfaceElevated else palette.canvas,
                                    contentColor = if (isSelected) palette.primary else palette.textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = preset.substringBefore(" "),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    if (activePlaylist != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = activeUaDraft,
                                onValueChange = { activeUaDraft = it },
                                singleLine = true,
                                label = { Text("Active Playlist User-Agent") },
                                colors = fieldColors,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    onUpdateDefaultUserAgent(activeUaDraft)
                                    onUpdatePlaylistUserAgent(activePlaylist.id, activeUaDraft)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.primary,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Apply", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onVerifyCaptcha(activePlaylist.url) },
                                border = BorderStroke(1.dp, palette.secondary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = palette.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Verify Captcha",
                                    color = palette.textPrimary,
                                    fontSize = 12.sp
                                )
                            }

                            OutlinedButton(
                                onClick = onReloadActive,
                                border = BorderStroke(1.dp, palette.border),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = palette.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Reload Playlist",
                                    color = palette.textPrimary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = palette.border)

                    // 4. Add Unlimited M3U / M3U8 Playlists
                    Text(
                        text = "Add M3U / M3U8 Playlist",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        label = { Text("Playlist Name") },
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newUrl,
                        onValueChange = { newUrl = it },
                        singleLine = true,
                        label = { Text("M3U / M3U8 URL") },
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newUserAgent,
                        onValueChange = { newUserAgent = it },
                        singleLine = true,
                        label = { Text("User-Agent") },
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (newUrl.isNotBlank()) {
                                onAddPlaylist(newName, newUrl, newUserAgent)
                                newName = ""
                                newUrl = ""
                            }
                        },
                        enabled = newUrl.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.primary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Playlist", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }

                    HorizontalDivider(color = palette.border)

                    // 5. Saved Playlists (Unlimited)
                    Text(
                        text = "Saved Playlists (${playlists.size})",
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        playlists.forEach { source ->
                            val isActive = source.id == activePlaylistId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (isActive) palette.surfaceElevated else palette.canvas,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectPlaylist(source.id) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = source.name,
                                        color = if (isActive) palette.primary else palette.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${source.url} · UA: ${source.userAgent}",
                                        color = palette.textSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onVerifyCaptcha(source.url) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Security,
                                            contentDescription = "Verify Captcha",
                                            tint = palette.secondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    if (isActive) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Active",
                                            tint = palette.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    if (playlists.size > 1) {
                                        IconButton(
                                            onClick = { onDeletePlaylist(source.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete playlist",
                                                tint = palette.errorRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
