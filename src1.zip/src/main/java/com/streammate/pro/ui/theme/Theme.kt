package com.streammate.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.streammate.pro.model.AppThemeId

@Immutable
data class StreamMatePalette(
    val id: AppThemeId,
    val canvas: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val primary: Color,
    val secondary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val liveGreen: Color,
    val errorRed: Color,
    val favoriteGold: Color
) {
    val headerBrush: Brush
        get() = Brush.horizontalGradient(
            colors = listOf(
                primary.copy(alpha = 0.28f),
                secondary.copy(alpha = 0.24f),
                surface
            )
        )

    val accentBrush: Brush
        get() = Brush.horizontalGradient(
            colors = listOf(primary, secondary)
        )
}

fun paletteForTheme(themeId: AppThemeId): StreamMatePalette = when (themeId) {
    AppThemeId.CYBER_NEON -> StreamMatePalette(
        id = AppThemeId.CYBER_NEON,
        canvas = Color(0xFF070A12),
        surface = Color(0xFF0F1524),
        surfaceElevated = Color(0xFF172036),
        border = Color(0xFF232E4A),
        primary = Color(0xFF00E5FF),
        secondary = Color(0xFF7C3AED),
        textPrimary = Color(0xFFF1F5F9),
        textSecondary = Color(0xFF94A3B8),
        liveGreen = Color(0xFF10B981),
        errorRed = Color(0xFFEF4444),
        favoriteGold = Color(0xFFFACC15)
    )

    AppThemeId.ROYAL_GOLD_SUNSET -> StreamMatePalette(
        id = AppThemeId.ROYAL_GOLD_SUNSET,
        canvas = Color(0xFF0D0A0B),
        surface = Color(0xFF171114),
        surfaceElevated = Color(0xFF241A1F),
        border = Color(0xFF3A2830),
        primary = Color(0xFFF59E0B),
        secondary = Color(0xFFF43F5E),
        textPrimary = Color(0xFFFAF5F0),
        textSecondary = Color(0xFFB5A3A8),
        liveGreen = Color(0xFF10B981),
        errorRed = Color(0xFFFB7185),
        favoriteGold = Color(0xFFFBBF24)
    )

    AppThemeId.EMERALD_AURORA -> StreamMatePalette(
        id = AppThemeId.EMERALD_AURORA,
        canvas = Color(0xFF060D0C),
        surface = Color(0xFF0D1917),
        surfaceElevated = Color(0xFF142724),
        border = Color(0xFF1E3A35),
        primary = Color(0xFF10B981),
        secondary = Color(0xFF06B6D4),
        textPrimary = Color(0xFFECFDF5),
        textSecondary = Color(0xFF8FB3AA),
        liveGreen = Color(0xFF34D399),
        errorRed = Color(0xFFEF4444),
        favoriteGold = Color(0xFFFACC15)
    )
}

val LocalStreamMatePalette = staticCompositionLocalOf {
    paletteForTheme(AppThemeId.CYBER_NEON)
}

@Composable
fun StreamMateTheme(
    themeId: AppThemeId,
    content: @Composable () -> Unit
) {
    val palette = paletteForTheme(themeId)
    val colorScheme = darkColorScheme(
        primary = palette.primary,
        secondary = palette.secondary,
        onPrimary = Color.Black,
        background = palette.canvas,
        onBackground = palette.textPrimary,
        surface = palette.surface,
        onSurface = palette.textPrimary,
        surfaceVariant = palette.surfaceElevated,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.border,
        error = palette.errorRed
    )

    CompositionLocalProvider(LocalStreamMatePalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
