package com.streammate.pro.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import com.streammate.pro.data.PlaylistRepository
import com.streammate.pro.model.AppThemeId
import com.streammate.pro.model.AspectRatioMode
import com.streammate.pro.model.Category
import com.streammate.pro.model.Channel
import com.streammate.pro.model.IptvUiState
import com.streammate.pro.model.PlaylistSource
import com.streammate.pro.player.ExoPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class IptvViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PlaylistRepository(application)
    val playerManager = ExoPlayerManager(application)

    private val _uiState = MutableStateFlow(IptvUiState())
    val uiState: StateFlow<IptvUiState> = _uiState.asStateFlow()

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            _uiState.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    playerError = if (playbackState == Player.STATE_READY) null else it.playerError
                )
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
        }

        override fun onPlayerError(error: PlaybackException) {
            _uiState.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    playerError = error.localizedMessage ?: "Stream playback failed"
                )
            }
        }
    }

    init {
        playerManager.player.addListener(playerListener)
        val savedPlaylists = repository.loadSavedPlaylists()
        val activeId = repository.getActivePlaylistId()
        val activeSource = savedPlaylists.find { it.id == activeId } ?: savedPlaylists.first()

        _uiState.update {
            it.copy(
                playlists = savedPlaylists,
                activePlaylistId = activeSource.id,
                favoriteStreamUrls = repository.getFavoriteUrls(),
                themeId = repository.getThemeId(),
                startOnBoot = repository.getStartOnBoot(),
                autoPlayLastChannel = repository.getAutoPlayLastChannel(),
                defaultUserAgent = repository.getDefaultUserAgent()
            )
        }
        loadPlaylist(activeSource, autoPlayOnLoad = true)
    }

    fun selectCategory(categoryName: String) {
        _uiState.update { it.copy(selectedCategory = categoryName) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun toggleFavorite(channel: Channel) {
        val current = _uiState.value.favoriteStreamUrls
        val updated = if (current.contains(channel.streamUrl)) {
            current - channel.streamUrl
        } else {
            current + channel.streamUrl
        }
        repository.saveFavoriteUrls(updated)
        _uiState.update { state ->
            state.copy(
                favoriteStreamUrls = updated,
                categories = buildCategories(state.channels, updated)
            )
        }
    }

    fun playChannel(channel: Channel) {
        val activePlaylist = _uiState.value.playlists.find { it.id == _uiState.value.activePlaylistId }
        val userAgent = channel.customUserAgent
            ?: activePlaylist?.userAgent
            ?: _uiState.value.defaultUserAgent

        repository.setLastChannelUrl(channel.streamUrl)
        _uiState.update {
            it.copy(
                activeChannel = channel,
                playerError = null,
                isBuffering = true
            )
        }
        playerManager.playStream(
            streamUrl = channel.streamUrl,
            userAgent = userAgent,
            httpHeaders = channel.httpHeaders,
            drmLicenseType = channel.drmLicenseType,
            drmLicenseUrl = channel.drmLicenseUrl
        )
    }

    fun cycleAspectRatio() {
        val next = when (_uiState.value.aspectMode) {
            AspectRatioMode.FIT -> AspectRatioMode.FILL
            AspectRatioMode.FILL -> AspectRatioMode.ZOOM
            AspectRatioMode.ZOOM -> AspectRatioMode.FIT
        }
        _uiState.update { it.copy(aspectMode = next) }
    }

    fun toggleFullscreen() {
        _uiState.update { it.copy(isFullscreen = !it.isFullscreen) }
    }

    fun toggleSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun setTheme(themeId: AppThemeId) {
        repository.setThemeId(themeId)
        _uiState.update { it.copy(themeId = themeId) }
    }

    fun setStartOnBoot(enabled: Boolean) {
        repository.setStartOnBoot(enabled)
        _uiState.update { it.copy(startOnBoot = enabled) }
    }

    fun setAutoPlayLastChannel(enabled: Boolean) {
        repository.setAutoPlayLastChannel(enabled)
        _uiState.update { it.copy(autoPlayLastChannel = enabled) }
    }

    fun setDefaultUserAgent(userAgent: String) {
        val resolved = userAgent.trim().ifBlank { PlaylistSource.DEFAULT_USER_AGENT }
        repository.setDefaultUserAgent(resolved)
        _uiState.update { it.copy(defaultUserAgent = resolved) }
    }

    fun addPlaylist(name: String, url: String, userAgent: String) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isBlank()) return

        val resolvedName = name.trim().ifBlank { "Playlist ${_uiState.value.playlists.size + 1}" }
        val resolvedUa = userAgent.trim().ifBlank { _uiState.value.defaultUserAgent }

        val newPlaylist = PlaylistSource(
            id = UUID.randomUUID().toString(),
            name = resolvedName,
            url = trimmedUrl,
            userAgent = resolvedUa
        )

        val updated = _uiState.value.playlists + newPlaylist
        repository.savePlaylists(updated)
        repository.setActivePlaylistId(newPlaylist.id)

        _uiState.update {
            it.copy(
                playlists = updated,
                activePlaylistId = newPlaylist.id,
                showSettingsDialog = false
            )
        }
        loadPlaylist(newPlaylist, autoPlayOnLoad = true)
    }

    fun selectPlaylist(playlistId: String) {
        val source = _uiState.value.playlists.find { it.id == playlistId } ?: return
        repository.setActivePlaylistId(source.id)
        _uiState.update {
            it.copy(
                activePlaylistId = source.id,
                showSettingsDialog = false
            )
        }
        loadPlaylist(source, autoPlayOnLoad = true)
    }

    fun updatePlaylistUserAgent(playlistId: String, newUserAgent: String) {
        val resolvedUa = newUserAgent.trim().ifBlank { _uiState.value.defaultUserAgent }
        val updated = _uiState.value.playlists.map {
            if (it.id == playlistId) it.copy(userAgent = resolvedUa) else it
        }
        repository.savePlaylists(updated)
        _uiState.update { it.copy(playlists = updated) }

        val activeSource = updated.find { it.id == _uiState.value.activePlaylistId }
        if (activeSource != null && activeSource.id == playlistId) {
            loadPlaylist(activeSource, autoPlayOnLoad = false)
            _uiState.value.activeChannel?.let { playChannel(it) }
        }
    }

    fun deletePlaylist(playlistId: String) {
        val currentList = _uiState.value.playlists
        if (currentList.size <= 1) return

        val updated = currentList.filterNot { it.id == playlistId }
        repository.savePlaylists(updated)

        val nextActiveId = if (_uiState.value.activePlaylistId == playlistId) {
            updated.first().id
        } else {
            _uiState.value.activePlaylistId
        }
        repository.setActivePlaylistId(nextActiveId)

        _uiState.update {
            it.copy(
                playlists = updated,
                activePlaylistId = nextActiveId
            )
        }

        updated.find { it.id == nextActiveId }?.let { loadPlaylist(it, autoPlayOnLoad = false) }
    }

    fun openCaptchaVerify(url: String) {
        _uiState.update { it.copy(captchaVerifyUrl = url) }
    }

    fun dismissCaptchaVerify() {
        _uiState.update { it.copy(captchaVerifyUrl = null) }
    }

    fun completeCaptchaAndReload() {
        _uiState.update { it.copy(captchaVerifyUrl = null) }
        reloadActivePlaylist()
    }

    fun reloadActivePlaylist() {
        val source = _uiState.value.playlists.find { it.id == _uiState.value.activePlaylistId } ?: return
        loadPlaylist(source, autoPlayOnLoad = false)
    }

    private fun buildCategories(channels: List<Channel>, favorites: Set<String>): List<Category> {
        val favCount = channels.count { favorites.contains(it.streamUrl) }
        val grouped = channels.groupBy { it.category }
        return buildList {
            add(Category("All", channels.size))
            add(Category("Favorites", favCount))
            grouped.entries
                .sortedBy { it.key }
                .forEach { (cat, list) ->
                    add(Category(cat, list.size))
                }
        }
    }

    private fun loadPlaylist(source: PlaylistSource, autoPlayOnLoad: Boolean) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoadingPlaylist = true,
                    playlistError = null
                )
            }

            repository.fetchChannels(source)
                .onSuccess { channels ->
                    val categories = buildCategories(channels, _uiState.value.favoriteStreamUrls)

                    _uiState.update { state ->
                        state.copy(
                            isLoadingPlaylist = false,
                            channels = channels,
                            categories = categories,
                            selectedCategory = "All",
                            playlistError = if (channels.isEmpty()) "No playable channels found in M3U." else null
                        )
                    }

                    if (autoPlayOnLoad && channels.isNotEmpty() && _uiState.value.autoPlayLastChannel) {
                        val lastUrl = repository.getLastChannelUrl()
                        val target = channels.find { it.streamUrl == lastUrl } ?: channels.first()
                        playChannel(target)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoadingPlaylist = false,
                            playlistError = error.localizedMessage ?: "Failed to load playlist"
                        )
                    }
                }
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.player.removeListener(playerListener)
        playerManager.release()
    }
}
