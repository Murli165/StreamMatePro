package com.streammate.pro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.streammate.pro.model.Category
import com.streammate.pro.model.Channel
import com.streammate.pro.ui.components.CaptchaWebViewDialog
import com.streammate.pro.ui.components.SettingsDialog
import com.streammate.pro.ui.components.TopVideoPlayer
import com.streammate.pro.ui.theme.LocalStreamMatePalette

@Composable
fun IptvPlayerScreen(
    viewModel: IptvViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val palette = LocalStreamMatePalette.current
    val activePlaylist = uiState.playlists.find { it.id == uiState.activePlaylistId }
    val activeUserAgent = activePlaylist?.userAgent ?: uiState.defaultUserAgent

    val filteredChannels = remember(
        uiState.channels,
        uiState.selectedCategory,
        uiState.searchQuery,
        uiState.favoriteStreamUrls
    ) {
        uiState.channels.filter { channel ->
            val matchesCategory = when (uiState.selectedCategory) {
                "All" -> true
                "Favorites" -> uiState.favoriteStreamUrls.contains(channel.streamUrl)
                else -> channel.category == uiState.selectedCategory
            }
            val matchesQuery = uiState.searchQuery.isBlank() ||
                channel.name.contains(uiState.searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .then(if (uiState.isFullscreen) Modifier else Modifier.statusBarsPadding())
    ) {
        if (!uiState.isFullscreen) {
            // Glowing Gradient Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.headerBrush)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "StreamMate Pro",
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${activePlaylist?.name ?: "Playlist"} · ${uiState.themeId.displayName}",
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (activePlaylist != null) {
                        IconButton(onClick = { viewModel.openCaptchaVerify(activePlaylist.url) }) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Verify Captcha",
                                tint = palette.secondary
                            )
                        }
                    }
                    IconButton(onClick = { viewModel.toggleSettingsDialog(true) }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = palette.primary
                        )
                    }
                }
            }
            HorizontalDivider(color = palette.border)
        }

        // Top ExoPlayer Video Player with Fit/Fill/Zoom & Settings Button
        TopVideoPlayer(
            exoPlayer = viewModel.playerManager.player,
            activeChannel = uiState.activeChannel,
            userAgent = activeUserAgent,
            aspectMode = uiState.aspectMode,
            isBuffering = uiState.isBuffering,
            playerError = uiState.playerError,
            isFullscreen = uiState.isFullscreen,
            onCycleAspectRatio = viewModel::cycleAspectRatio,
            onToggleFullscreen = viewModel::toggleFullscreen,
            onOpenSettings = { viewModel.toggleSettingsDialog(true) },
            onRetry = { uiState.activeChannel?.let(viewModel::playChannel) }
        )

        if (!uiState.isFullscreen) {
            HorizontalDivider(color = palette.border)

            // Bottom Split: Categories on the Left, Channels on the Right
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                CategoryPane(
                    categories = uiState.categories,
                    selectedCategory = uiState.selectedCategory,
                    onSelectCategory = viewModel::selectCategory,
                    modifier = Modifier
                        .weight(0.34f)
                        .fillMaxHeight()
                        .background(palette.surface)
                )

                VerticalDivider(color = palette.border)

                ChannelPane(
                    channels = filteredChannels,
                    favoriteStreamUrls = uiState.favoriteStreamUrls,
                    activeChannelId = uiState.activeChannel?.id,
                    searchQuery = uiState.searchQuery,
                    isLoading = uiState.isLoadingPlaylist,
                    errorMessage = uiState.playlistError,
                    onSearchChange = viewModel::updateSearchQuery,
                    onChannelClick = viewModel::playChannel,
                    onToggleFavorite = viewModel::toggleFavorite,
                    onVerifyCaptcha = {
                        activePlaylist?.let { viewModel.openCaptchaVerify(it.url) }
                    },
                    modifier = Modifier
                        .weight(0.66f)
                        .fillMaxHeight()
                        .background(palette.canvas)
                )
            }
        }
    }

    if (uiState.showSettingsDialog) {
        SettingsDialog(
            playlists = uiState.playlists,
            activePlaylistId = uiState.activePlaylistId,
            themeId = uiState.themeId,
            startOnBoot = uiState.startOnBoot,
            autoPlayLastChannel = uiState.autoPlayLastChannel,
            defaultUserAgent = uiState.defaultUserAgent,
            onDismiss = { viewModel.toggleSettingsDialog(false) },
            onSelectTheme = viewModel::setTheme,
            onToggleStartOnBoot = viewModel::setStartOnBoot,
            onToggleAutoPlayLast = viewModel::setAutoPlayLastChannel,
            onUpdateDefaultUserAgent = viewModel::setDefaultUserAgent,
            onAddPlaylist = viewModel::addPlaylist,
            onSelectPlaylist = viewModel::selectPlaylist,
            onUpdatePlaylistUserAgent = viewModel::updatePlaylistUserAgent,
            onDeletePlaylist = viewModel::deletePlaylist,
            onVerifyCaptcha = { url -> viewModel.openCaptchaVerify(url) },
            onReloadActive = viewModel::reloadActivePlaylist
        )
    }

    val captchaUrl = uiState.captchaVerifyUrl
    if (captchaUrl != null) {
        CaptchaWebViewDialog(
            url = captchaUrl,
            userAgent = activeUserAgent,
            onDismiss = viewModel::dismissCaptchaVerify,
            onDoneAndReload = viewModel::completeCaptchaAndReload
        )
    }
}

@Composable
private fun CategoryPane(
    categories: List<Category>,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalStreamMatePalette.current

    Column(modifier = modifier) {
        Text(
            text = "Categories",
            color = palette.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        )
        HorizontalDivider(color = palette.border)

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(categories, key = { it.name }) { category ->
                val isSelected = category.name == selectedCategory
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isSelected) palette.surfaceElevated else Color.Transparent)
                        .focusable()
                        .clickable { onSelectCategory(category.name) }
                        .padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = category.name,
                        color = if (isSelected) palette.primary else palette.textPrimary,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = category.channelCount.toString(),
                        color = palette.textSecondary,
                        fontSize = 11.sp
                    )
                }
                HorizontalDivider(color = palette.border.copy(alpha = 0.45f))
            }
        }
    }
}

@Composable
private fun ChannelPane(
    channels: List<Channel>,
    favoriteStreamUrls: Set<String>,
    activeChannelId: String?,
    searchQuery: String,
    isLoading: Boolean,
    errorMessage: String?,
    onSearchChange: (String) -> Unit,
    onChannelClick: (Channel) -> Unit,
    onToggleFavorite: (Channel) -> Unit,
    onVerifyCaptcha: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalStreamMatePalette.current

    Column(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                singleLine = true,
                placeholder = {
                    Text("Search channels...", color = palette.textSecondary, fontSize = 13.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = palette.primary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.primary,
                    unfocusedBorderColor = palette.border,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }
        HorizontalDivider(color = palette.border)

        when {
            isLoading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = palette.primary, modifier = Modifier.size(30.dp))
                }
            }

            errorMessage != null && channels.isEmpty() -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = errorMessage,
                        color = palette.errorRed,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.size(10.dp))
                    Button(
                        onClick = onVerifyCaptcha,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.primary,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Verify Captcha", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            channels.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No channels in this category",
                        color = palette.textSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(channels, key = { it.id }) { channel ->
                        val isPlaying = channel.id == activeChannelId
                        val isFavorite = favoriteStreamUrls.contains(channel.streamUrl)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isPlaying) palette.surfaceElevated else Color.Transparent)
                                .focusable()
                                .clickable { onChannelClick(channel) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = channel.number.toString().padStart(2, '0'),
                                color = if (isPlaying) palette.primary else palette.textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.width(32.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(palette.surface),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!channel.logoUrl.isNullOrBlank()) {
                                    AsyncImage(
                                        model = channel.logoUrl,
                                        contentDescription = channel.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = null,
                                        tint = palette.textSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = channel.name,
                                    color = if (isPlaying) palette.primary else palette.textPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = if (isPlaying) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = channel.category,
                                    color = palette.textSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(
                                onClick = { onToggleFavorite(channel) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                    contentDescription = if (isFavorite) "Remove favorite" else "Add favorite",
                                    tint = if (isFavorite) palette.favoriteGold else palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            if (isPlaying) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Playing",
                                    tint = palette.liveGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        HorizontalDivider(color = palette.border.copy(alpha = 0.45f))
                    }
                }
            }
        }
    }
}
