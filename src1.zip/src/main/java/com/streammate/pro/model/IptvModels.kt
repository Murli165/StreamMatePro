package com.streammate.pro.model

enum class AppThemeId(val displayName: String) {
    CYBER_NEON("Cyber Neon"),
    ROYAL_GOLD_SUNSET("Royal Gold Sunset"),
    EMERALD_AURORA("Emerald Aurora")
}

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    ZOOM("Zoom")
}

data class PlaylistSource(
    val id: String,
    val name: String,
    val url: String,
    val userAgent: String = DEFAULT_USER_AGENT
) {
    companion object {
        const val DEFAULT_USER_AGENT = "TiviMate/4.7.0 (Linux; Android 12)"
        const val PRELOADED_URL = "https://allinonereborn2.online/jiotv-m3u/jtv39.m3u8"
        const val PRELOADED_NAME = "JioTV Master M3U"

        val USER_AGENT_PRESETS = listOf(
            "TiviMate/4.7.0 (Linux; Android 12)",
            "IPTV Smarters Pro/3.1 (Linux; Android 13)",
            "VLC/3.0.20 LibVLC/3.0.20",
            "Kodi/21.0 (Linux; Android 12)"
        )
    }
}

data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val streamUrl: String,
    val category: String,
    val logoUrl: String? = null,
    val tvgId: String? = null,
    val customUserAgent: String? = null,
    val drmLicenseType: String? = null,
    val drmLicenseUrl: String? = null,
    val httpHeaders: Map<String, String> = emptyMap()
)

data class Category(
    val name: String,
    val channelCount: Int
)

data class IptvUiState(
    val playlists: List<PlaylistSource> = emptyList(),
    val activePlaylistId: String = "",
    val categories: List<Category> = emptyList(),
    val selectedCategory: String = "All",
    val channels: List<Channel> = emptyList(),
    val favoriteStreamUrls: Set<String> = emptySet(),
    val searchQuery: String = "",
    val activeChannel: Channel? = null,
    val isLoadingPlaylist: Boolean = false,
    val playlistError: String? = null,
    val isBuffering: Boolean = false,
    val isPlaying: Boolean = false,
    val playerError: String? = null,
    val isFullscreen: Boolean = false,
    val aspectMode: AspectRatioMode = AspectRatioMode.FIT,
    val themeId: AppThemeId = AppThemeId.CYBER_NEON,
    val startOnBoot: Boolean = false,
    val autoPlayLastChannel: Boolean = true,
    val defaultUserAgent: String = PlaylistSource.DEFAULT_USER_AGENT,
    val showSettingsDialog: Boolean = false,
    val captchaVerifyUrl: String? = null
)
