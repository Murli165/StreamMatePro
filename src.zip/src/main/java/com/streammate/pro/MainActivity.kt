package com.streammate.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.streammate.pro.ui.IptvPlayerScreen
import com.streammate.pro.ui.IptvViewModel
import com.streammate.pro.ui.theme.StreamMateTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            val viewModel: IptvViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsState()
            StreamMateTheme(themeId = uiState.themeId) {
                IptvPlayerScreen(viewModel = viewModel)
            }
        }
    }
}
