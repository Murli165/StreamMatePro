package com.streammate.pro

import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// --- Nuvio Pitch-Black Colors ---
val BgBlack = Color(0xFF070709)
val CardDark = Color(0xFF131318)
val CardElevated = Color(0xFF1C1C24)
val BorderSubtle = Color(0xFF282834)
val AccentPurple = Color(0xFF00D4FF)
val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFF9A9AA6)

// --- Data Models ---
data class Channel(
    val id: String,
    val name: String,
    val url: String,
    val logo: String = "",
    val group: String = "Uncategorized"
)

data class PlaylistSource(
    val id: String,
    val name: String,
    val type: String, // "M3U", "XTREAM", "STALKER"
    val url: String,
    val extra: String = "" // MAC or EPG info
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = BgBlack,
                    surface = CardDark,
                    primary = AccentPurple,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                StreamMateProApp()
            }
        }
    }
}

@Composable
fun StreamMateProApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("streammate_nuvio", Context.MODE_PRIVATE) }

    var currentTab by remember { mutableIntStateOf(0) } // 0:Home, 1:Live, 2:Search, 3:Library, 4:Sources
    var sources by remember { mutableStateOf(loadSources(prefs)) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var favoriteIds by remember { mutableStateOf(prefs.getStringSet("favs", emptySet()) ?: emptySet()) }
    var recentIds by remember { mutableStateOf(loadRecentIds(prefs)) }
    var playingChannel by remember { mutableStateOf<Channel?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }

    fun refreshAllChannels(sourceList: List<PlaylistSource>) {
        if (sourceList.isEmpty()) {
            channels = emptyList()
            return
        }
        scope.launch {
            isLoading = true
            statusMsg = "Loading playlists..."
            val allLoaded = mutableListOf<Channel>()
            for (src in sourceList) {
                if (src.type == "M3U" || src.type == "XTREAM") {
                    val parsed = fetchAndParseM3U(src.url)
                    allLoaded.addAll(parsed)
                }
            }
            channels = allLoaded.distinctBy { it.url }
            statusMsg = if (channels.isEmpty()) "No channels found. Check URL." else "${channels.size} channels loaded"
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        if (sources.isNotEmpty()) refreshAllChannels(sources)
    }

    fun toggleFavorite(channel: Channel) {
        val updated = favoriteIds.toMutableSet()
        if (updated.contains(channel.id)) updated.remove(channel.id) else updated.add(channel.id)
        favoriteIds = updated
        prefs.edit().putStringSet("favs", updated).apply()
    }

    fun playChannel(channel: Channel) {
        playingChannel = channel
        val updatedRecent = (listOf(channel.id) + recentIds.filter { it != channel.id }).take(15)
        recentIds = updatedRecent
        prefs.edit().putString("recents", updatedRecent.joinToString(",")).apply()
    }

    if (playingChannel != null) {
        BackHandler { playingChannel = null }
        NuvioPlayerScreen(
            channel = playingChannel!!,
            isFavorite = favoriteIds.contains(playingChannel!!.id),
            onToggleFavorite = { toggleFavorite(playingChannel!!) },
            onBack = { playingChannel = null }
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgBlack)
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(bottom = 84.dp)) {
            when (currentTab) {
                0 -> HomeScreen(
                    channels = channels,
                    recentIds = recentIds,
                    favoriteIds = favoriteIds,
                    isLoading = isLoading,
                    onPlay = ::playChannel,
                    onGoToSources = { currentTab = 4 },
                    onGoToLive = { currentTab = 1 }
                )
                1 -> LiveTvScreen(
                    channels = channels,
                    favoriteIds = favoriteIds,
                    isLoading = isLoading,
                    onPlay = ::playChannel,
                    onToggleFav = ::toggleFavorite,
                    onRefresh = { refreshAllChannels(sources) }
                )
                2 -> SearchScreen(
                    channels = channels,
                    onPlay = ::playChannel
                )
                3 -> LibraryScreen(
                    channels = channels,
                    favoriteIds = favoriteIds,
                    recentIds = recentIds,
                    onPlay = ::playChannel,
                    onToggleFav = ::toggleFavorite
                )
                4 -> SourcesScreen(
                    sources = sources,
                    statusMsg = statusMsg,
                    onAddSource = { newSrc ->
                        val updated = sources + newSrc
                        sources = updated
                        saveSources(prefs, updated)
                        refreshAllChannels(updated)
                    },
                    onDeleteSource = { delSrc ->
                        val updated = sources.filter { it.id != delSrc.id }
                        sources = updated
                        saveSources(prefs, updated)
                        refreshAllChannels(updated)
                    },
                    onRefresh = { refreshAllChannels(sources) }
                )
            }
        }

        // --- Nuvio Floating Pill Bottom Navigation Bar ---
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .navigationBarsPadding()
                .height(62.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(32.dp),
            color = Color(0xEE16161D),
            border = BorderStroke(1.dp, BorderSubtle),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavPillItem(Icons.Default.Home, "Home", currentTab == 0) { currentTab = 0 }
                NavPillItem(Icons.Default.LiveTv, "Live TV", currentTab == 1) { currentTab = 1 }
                NavPillItem(Icons.Default.Search, "Search", currentTab == 2) { currentTab = 2 }
                NavPillItem(Icons.Default.Bookmarks, "Library", currentTab == 3) { currentTab = 3 }
                NavPillItem(Icons.Default.Settings, "Sources", currentTab == 4) { currentTab = 4 }
            }
        }
    }
}

@Composable
fun NavPillItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .background(if (selected) AccentPurple.copy(alpha = 0.2f) else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) Color.White else TextSecondary,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) Color.White else TextSecondary
        )
    }
}

// --- 1. HOME SCREEN ---
@Composable
fun HomeScreen(
    channels: List<Channel>,
    recentIds: List<String>,
    favoriteIds: Set<String>,
    isLoading: Boolean,
    onPlay: (Channel) -> Unit,
    onGoToSources: () -> Unit,
    onGoToLive: () -> Unit
) {
    val recentChannels = recentIds.mapNotNull { id -> channels.find { it.id == id } }
    val favChannels = channels.filter { favoriteIds.contains(it.id) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("StreamMate Pro", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = AccentPurple)
                }
            }
        }

        // Featured Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF23164A), Color(0xFF101018)))
                    )
                    .clickable {
                        if (channels.isNotEmpty()) onPlay(channels.first()) else onGoToSources()
                    }
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.align(Alignment.BottomStart),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (channels.isEmpty()) "WELCOME TO STREAMMATE" else "READY TO WATCH",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentPurple,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (channels.isEmpty()) "Add M3U, Xtream or Stalker" else "${channels.size} Live Channels Ready",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Button(
                        onClick = { if (channels.isEmpty()) onGoToSources() else onGoToLive() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        shape = RoundedCornerShape(24.dp),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (channels.isEmpty()) "Add Source" else "Browse Live TV", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Continue Watching Row
        if (recentChannels.isNotEmpty()) {
            item {
                Text("Continue Watching", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recentChannels) { ch ->
                        ChannelPosterCard(ch) { onPlay(ch) }
                    }
                }
            }
        }

        // Favorites Row
        if (favChannels.isNotEmpty()) {
            item {
                Text("Your Favorites", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(favChannels) { ch ->
                        ChannelPosterCard(ch) { onPlay(ch) }
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelPosterCard(channel: Channel, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .width(145.dp)
            .height(105.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = CardDark,
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (channel.logo.isNotBlank()) {
                AsyncImage(
                    model = channel.logo,
                    contentDescription = channel.name,
                    modifier = Modifier.height(48.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Fit
                )
            } else {
                Icon(Icons.Default.Tv, null, tint = AccentPurple, modifier = Modifier.size(40.dp))
            }
            Text(
                text = channel.name,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// --- 2. LIVE TV SCREEN (Categories + Channels) ---
@Composable
fun LiveTvScreen(
    channels: List<Channel>,
    favoriteIds: Set<String>,
    isLoading: Boolean,
    onPlay: (Channel) -> Unit,
    onToggleFav: (Channel) -> Unit,
    onRefresh: () -> Unit
) {
    val groups = remember(channels) { listOf("All") + channels.map { it.group }.distinct().sorted() }
    var selectedGroup by remember { mutableStateOf("All") }
    val filtered = remember(channels, selectedGroup) {
        if (selectedGroup == "All") channels else channels.filter { it.group == selectedGroup }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Live TV", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, "Refresh", tint = TextPrimary)
            }
        }

        // Category Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            items(groups) { grp ->
                val active = grp == selectedGroup
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (active) Color.White else CardElevated,
                    border = BorderStroke(1.dp, if (active) Color.White else BorderSubtle),
                    modifier = Modifier.clickable { selectedGroup = grp }
                ) {
                    Text(
                        text = grp,
                        color = if (active) Color.Black else TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentPurple)
            }
        } else if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No channels yet. Add a playlist in Sources tab.", color = TextSecondary)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered) { ch ->
                    ChannelRowItem(
                        channel = ch,
                        isFavorite = favoriteIds.contains(ch.id),
                        onClick = { onPlay(ch) },
                        onToggleFav = { onToggleFav(ch) }
                    )
                }
            }
        }
    }
}

@Composable
fun ChannelRowItem(channel: Channel, isFavorite: Boolean, onClick: () -> Unit, onToggleFav: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = CardDark,
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(CardElevated),
                contentAlignment = Alignment.Center
            ) {
                if (channel.logo.isNotBlank()) {
                    AsyncImage(model = channel.logo, contentDescription = null, modifier = Modifier.size(38.dp), contentScale = ContentScale.Fit)
                } else {
                    Icon(Icons.Default.LiveTv, null, tint = AccentPurple)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(channel.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(channel.group, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
         